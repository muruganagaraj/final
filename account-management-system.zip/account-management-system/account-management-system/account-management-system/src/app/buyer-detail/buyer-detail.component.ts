import { Component, OnInit } from '@angular/core';
import { AddBuyerComponent } from 'app/add-buyer/add-buyer.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ViewModel } from './buyer-detail.viewmodel';
import { forkJoin } from "rxjs/observable/forkJoin";
import { Observable } from 'rxjs/Observable';
import { ConfirmationDialogService } from '../confirmaion-dialog/confirmation-dialog.service';
import { StorageHelper } from 'app/storage/storageHelper';
export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-buyer-detail',
  templateUrl: './buyer-detail.component.html',
  styleUrls: ['./buyer-detail.component.css']
})
export class BuyerDetailComponent implements OnInit {
  vm: ViewModel[] = [];
  constructor(public dialog: MatDialog,
    private http: HttpClient, 
    public storageHelper: StorageHelper,
    private confirmationDialogService: ConfirmationDialogService) { }
  ngOnInit() {
    const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
    this.getBuyerList(endpoint);
  }

  getBuyerList(endpoint: string): any {
    this.storageHelper.isBusy = true;
    return this.http.get(endpoint).subscribe(buyerList => {
      this.http.get('https://6d73py636l.execute-api.us-east-1.amazonaws.com/default/EDU_G_GetAll').subscribe(gstlist => {
        this.vm = this.getdata(buyerList, gstlist);
        this.storageHelper.isBusy = false;
      });
    });
  }

  getdata(buyerList: any, gstlist: any): ViewModel[] {
    return (buyerList || []).map((item: any) => <ViewModel>{
      BuyerId: item.BuyerId,
      BuyerCode: item.BuyerCode,
      GSTId: item.GSTId,
      Name: item.Name,
      Address: item.Address,
      ContactNo: item.ContactNo,
      GSTCode: gstlist.filter(x => x.GSTId === item.GSTId)[0]
        ? gstlist.filter(x => x.GSTId === item.GSTId)[0].GSTCode : undefined
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(AddBuyerComponent, {
      height: "auto",
      width: "auto",
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
        this.getBuyerList(endpoint);
      }
    });

  }
  onRemove(item: ViewModel): void {
    this.confirmationDialogService.confirm('are you sure?', item.Name + ' will be deleted.', item.BuyerId).then((res: any) => {
      if (res === true) {
        this.storageHelper.isBusy = true;
        let jsonString = JSON.stringify(item.BuyerId);
        this.http.post('https://6anzlfub48.execute-api.us-east-1.amazonaws.com/default/EDU_B_DeleteById',
          jsonString
        ).subscribe(result => {
          const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
          this.getBuyerList(endpoint);
        });
      }
    });
  }

  onEdit(item: ViewModel): void {
    const dialogRef = this.dialog.open(AddBuyerComponent, {
      height: "auto",
      width: "auto",
      data: { item }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
        this.getBuyerList(endpoint);
      }
    });
  }
}
