import { Component, OnInit } from '@angular/core';
import { AddGstComponent } from 'app/add-gst/add-gst.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { ConfirmationDialogService } from '../confirmaion-dialog/confirmation-dialog.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { reportModel, expensiveList } from 'app/report/report.component.viewmodel';
import { TextPairHelperService } from '../services/text-pair-helper.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import { StorageHelper } from 'app/storage/storageHelper';

export interface TextValuePair {
  key?: string;
  value?: string;
}

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  reportForm: FormGroup;
  maxDate = new Date();
  //buyerList: TextValuePair[];
  typeList: TextValuePair[];
  reportList: reportModel[] = [];
  reportListCopy: reportModel[] = [];
  reportDownloadForm: FormGroup;
  buyerList: TextPair[] = [];
  isDetailedShowClicked: boolean = false;
  isConsolidatedShowClicked: boolean = false;
  //   dataSource = ELEMENT_DATA;
  //   columnsToDisplay = ['name', 'weight', 'symbol', 'position'];
  //   expandedElement: PeriodicElement;
  constructor(private http: HttpClient,
    private textPairHelperService: TextPairHelperService,
    public storageHelper: StorageHelper) { }

  ngOnInit() {
    this.reportForm = new FormGroup({
      startDate: new FormControl(null, [Validators.required]),
      endDate: new FormControl(null, [Validators.required]),
      buyerValue: new FormControl(null, []),
    });
    this.reportDownloadForm = new FormGroup({
      downloadType: new FormControl(null, [Validators.required])
    });

    this.getBuyerList();
    this.isDetailedShowClicked = false;
    this.isConsolidatedShowClicked = false;
  }

  getBuyerList(): any {
    this.storageHelper.isBusy = true;
    const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
    this.http.get(endpoint).subscribe((item: any) => {
      this.buyerList = this.textPairHelperService.createBuyerTextPair(item);
      this.getExpensiveData()
      this.storageHelper.isBusy = false;
    });
  }

  getExpensiveData(): void {
    console.log('make api call');
    const endpoint: string = 'https://73hm04j8hh.execute-api.us-east-1.amazonaws.com/default/EDU_Expense_Get';
    this.http.get(endpoint).subscribe((item: any) => {
      if (item.length > 0) {
        this.reportList = this.getViewmodalData(item);
        this.reportListCopy = Object.assign([], this.reportList);
      }
    });
  }

  getViewmodalData(item: any): reportModel[] {
    return (item || []).map((list: any) => <reportModel>{
      buyername: this.textPairHelperService.getTextPairText(this.buyerList, list.BuyerId),
      buyerId: list.BuyerId,
      expensivedate: new Date(list.ExpenseDate),
      totalamount: list.TotalItemAmount,
      gst: list.TotalAmountWithGST,
      isgstrequired: list.IsGSTRequired,
      gstpercentage: list.GST,
      discount: list.Discount,
      finalamount: list.FinalAmount,
      items: this.getItemList(list.Items)
    });
  }

  getItemList(item: any): expensiveList[] {
    return (item || []).map((list: any) => <expensiveList>{
      itemcode: list.ItemCode,
      itemname: list.ItemName,
      quantity: list.Quantity,
      amount: list.Amount
    });
  }

  onDetailedShowClick(): void {
    const request: {} = {
      startDate: this.reportForm.controls['startDate'].value,
      endDate: this.reportForm.controls['endDate'].value,
      buyerValue: this.reportForm.controls['buyerValue'].value
    }
    console.log(request);
    this.isDetailedShowClicked = true;
    this.isConsolidatedShowClicked = false;
    let response: reportModel[] = this.reportListCopy.filter((x: reportModel) =>
      x.expensivedate < new Date(this.reportForm.controls['endDate'].value)
      && x.expensivedate > new Date(this.reportForm.controls['startDate'].value));
    if (this.reportForm.controls['buyerValue'].value) {
      let finalResponse: reportModel[] =
        response.filter((x: reportModel) => x.buyerId === this.reportForm.controls['buyerValue'].value)
      this.reportList = finalResponse;
    } else {
      this.reportList = response;
    }
    if (this.reportList.length === 0) {
      alert('No Record Found');
    }
  }

  onConsolidatedShowClick(): void {
    const request: {} = {
      startDate: this.reportForm.controls['startDate'].value,
      endDate: this.reportForm.controls['endDate'].value,
      buyerValue: this.reportForm.controls['buyerValue'].value
    }
    console.log(request);
    this.isDetailedShowClicked = false;
    this.isConsolidatedShowClicked = true;
    let response: reportModel[] = this.reportListCopy.filter((x: reportModel) =>
      x.expensivedate < new Date(this.reportForm.controls['endDate'].value)
      && x.expensivedate > new Date(this.reportForm.controls['startDate'].value));
    if (this.reportForm.controls['buyerValue'].value) {
      let finalResponse: reportModel[] =
        response.filter((x: reportModel) => x.buyerId === this.reportForm.controls['buyerValue'].value)
      this.reportList = finalResponse;
    } else {
      this.reportList = response;
    }
    if (this.reportList.length === 0) {
      alert('No Record Found');
    }
  }

  onDownloadClickDetailed() {
    var data = document.getElementById('contentToConvertDetailed');
    html2canvas(data).then(canvas => {
      // Few necessary setting options
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('MYPdf.pdf'); // Generated PDF
    });
  }

  onDownloadClickConsolidated() {
    var data = document.getElementById('contentToConvertConsolidated');
    html2canvas(data).then(canvas => {
      // Few necessary setting options
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('ExpenseReport.pdf'); // Generated PDF
    });
  }
}


