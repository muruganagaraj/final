import { Injectable } from '@angular/core';
import { BaseState, StateType } from './base-state.provider';

@Injectable()
export class StorageHelper extends BaseState {
    constructor() {
        super([
            { type: StateType.session, name: 'isBusy' }
        ])
    }

    public set isBusy(value: any) {
        this.setState('isBusy', value);
    }
    public get isBusy(): any {
        return this.getState<any>('isBusy') === 'true' ? true : false;
        
    }
}